$(window).scroll(function(){

	//console.log($(this).scrollTop());
	if ($(this).scrollTop() >= 600 && $(this).scrollTop() <= 800  ) { 
	  // $('#slide1 #box1-mountain').addClass('animated tada opacity');  
	   //$('#about-us .contents').addClass('animated shake opacity');
	}
});
